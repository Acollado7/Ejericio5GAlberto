package paqueteb;

public class Main {

    public static void main(String[] args) {

       PremiosLista lista = new PremiosLista();
         lista.ListaDePremios();
            lista.imprimirLista();


    }
}
